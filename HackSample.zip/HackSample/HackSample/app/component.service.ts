﻿import { Injectable, Input } from '@angular/core';
@Injectable()
export class ComponentService {
    mnth: any;
    sec: any;
}