"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var component_service_1 = require("./component.service");
var AppComponent = (function () {
    function AppComponent(serv) {
        this.serv = serv;
        this.clicked = false;
        this.dade = new Date();
        this.mnth = 0;
        this.see = false;
        this.user = "";
        this.key = [];
        this.name = 'Angular';
    }
    AppComponent.prototype.ngOnInit = function () {
        localStorage.clear();
    };
    AppComponent.prototype.check = function () {
        this.clicked = true;
        debugger;
        var j = JSON.stringify(this.clicked);
        localStorage.setItem(this.user, j);
        this.dade = new Date();
        this.serv.mnth = this.dade.getMinutes();
        this.sec = this.dade.getSeconds();
    };
    AppComponent.prototype.show = function () {
        this.see = true;
        for (var i = 0; i < localStorage.length; i++) {
            this.key[i] = localStorage.key(i);
        }
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'my-app',
        templateUrl: 'app.component.html'
    }),
    __metadata("design:paramtypes", [component_service_1.ComponentService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map